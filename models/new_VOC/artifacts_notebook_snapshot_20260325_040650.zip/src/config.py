from dataclasses import dataclass
from pathlib import Path


SENSOR_COLUMNS = [
    "timestamp",
    "ambient_temp",
    "ambient_humidity",
    "ambient_pressure",
    "coating_flow",
    "coating_conc",
    "coating_temp",
    "coating_pressure",
    "rotor_speed",
    "adsorption_fan_power",
    "desorption_fan_power",
    "rotor_inlet_temp",
    "rotor_inlet_humid",
    "desorption_temp",
    "concentrated_flow",
    "concentrated_conc",
    "concentrated_temp",
    "concentrated_pressure",
    "rto_in_flow",
    "rto_in_conc",
    "rto_in_temp",
    "rto_in_pressure",
    "burner_gas_flow",
    "combustion_temp",
    "rto_out_conc",
    "rto_out_temp",
]

TARGET_COLUMN = "rto_out_conc"
ROLLING_WINDOWS = (6, 12, 24, 48, 96)
TIME_FEATURE_COLUMNS = (
    "hour_sin",
    "hour_cos",
    "weekday_sin",
    "weekday_cos",
    "month_sin",
    "month_cos",
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
VOCS_ROOT = PROJECT_ROOT.parent / "VOCS"


@dataclass
class DataConfig:
    seq_len: int = 96
    pred_len: int = 24
    train_ratio: float = 0.7
    val_ratio: float = 0.15
    exceed_threshold: float = 80.0
    exceed_sample_weight: float = 1.0
    dataset_csv: Path = VOCS_ROOT / "src" / "data" / "vocs_dataset.csv"
    realtime_csv: Path = PROJECT_ROOT / "data" / "vocs_realtime_data.csv"
    scaler_path: Path = PROJECT_ROOT / "artifacts" / "models" / "voc_mamba_scalers.pkl"
    checkpoint_path: Path = PROJECT_ROOT / "artifacts" / "models" / "voc_mamba_best.pt"


@dataclass
class ModelConfig:
    d_model: int = 768
    n_layer: int = 16
    d_state: int = 128
    expand: int = 2
    headdim: int = 64
    dropout: float = 0.10
    ff_mult: int = 2
    chunk_size: int = 64
    rope_fraction: float = 0.5
    is_mimo: bool = False
    enable_exceed_aux_head: bool = False
    aux_head_hidden: int = 128
    predict_delta_from_last: bool = False
    max_parameters: int = 880_000_000


@dataclass
class TrainConfig:
    batch_size: int = 32
    epochs: int = 50
    learning_rate: float = 3e-4
    weight_decay: float = 1e-4
    grad_clip: float = 1.0
    early_stop_patience: int = 10
    seed: int = 42
    output_dir: Path = PROJECT_ROOT / "artifacts"
