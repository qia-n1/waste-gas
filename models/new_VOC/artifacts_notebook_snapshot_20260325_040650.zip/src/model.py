from __future__ import annotations

import torch
import torch.nn as nn

from .config import ModelConfig
from .vendor import ensure_mamba_ssm_importable

ensure_mamba_ssm_importable()

from mamba_ssm.modules.mamba3 import Mamba3  # noqa: E402


def _patch_mamba3_fallback_for_legacy_cuda() -> None:
    original = getattr(Mamba3, "_use_torch_fallback", None)
    if original is None or getattr(Mamba3, "_vocsmamba_fallback_patched", False):
        return

    def _patched(self, tensor: torch.Tensor) -> bool:
        if tensor.device.type == "cuda":
            major, minor = torch.cuda.get_device_capability(tensor.device)
            # Triton kernels used by current Mamba3 path require sm_75+.
            if (major, minor) < (7, 5):
                return True
        return original(self, tensor)

    Mamba3._use_torch_fallback = _patched  # type: ignore[assignment]
    Mamba3._vocsmamba_fallback_patched = True  # type: ignore[attr-defined]


_patch_mamba3_fallback_for_legacy_cuda()


def count_parameters(model: nn.Module) -> int:
    return sum(param.numel() for param in model.parameters())


class VocsMambaBlock(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.norm = nn.LayerNorm(config.d_model)
        self.mixer = Mamba3(
            d_model=config.d_model,
            d_state=config.d_state,
            expand=config.expand,
            headdim=config.headdim,
            rope_fraction=config.rope_fraction,
            chunk_size=config.chunk_size,
            is_mimo=config.is_mimo,
        )
        self.dropout = nn.Dropout(config.dropout)
        self.ffn_norm = nn.LayerNorm(config.d_model)
        ff_hidden = config.d_model * config.ff_mult
        self.ffn = nn.Sequential(
            nn.Linear(config.d_model, ff_hidden),
            nn.SiLU(),
            nn.Dropout(config.dropout),
            nn.Linear(ff_hidden, config.d_model),
        )

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = hidden_states + self.dropout(self.mixer(self.norm(hidden_states)))
        hidden_states = hidden_states + self.dropout(self.ffn(self.ffn_norm(hidden_states)))
        return hidden_states


class VocsMambaForecaster(nn.Module):
    def __init__(self, input_dim: int, config: ModelConfig, pred_len: int):
        super().__init__()
        self.config = config
        self.pred_len = pred_len
        self.enable_exceed_aux_head = config.enable_exceed_aux_head
        self.predict_delta_from_last = config.predict_delta_from_last
        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, config.d_model),
            nn.LayerNorm(config.d_model),
        )
        self.layers = nn.ModuleList([VocsMambaBlock(config) for _ in range(config.n_layer)])
        self.final_norm = nn.LayerNorm(config.d_model)
        self.head = nn.Sequential(
            nn.Linear(config.d_model * 2, config.d_model),
            nn.SiLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.d_model, pred_len),
        )
        if self.enable_exceed_aux_head:
            self.exceed_head = nn.Sequential(
                nn.Linear(config.d_model * 2, config.aux_head_hidden),
                nn.SiLU(),
                nn.Dropout(config.dropout),
                nn.Linear(config.aux_head_hidden, pred_len),
            )
        else:
            self.exceed_head = None

        total_params = count_parameters(self)
        if total_params > config.max_parameters:
            raise ValueError(
                f"Model has {total_params:,} parameters, exceeding the 880M cap ({config.max_parameters:,})."
            )

    def forward(self, inputs: torch.Tensor, return_aux: bool = False):
        hidden_states = self.input_proj(inputs)
        for layer in self.layers:
            hidden_states = layer(hidden_states)
        hidden_states = self.final_norm(hidden_states)
        summary = torch.cat([hidden_states[:, -1], hidden_states.mean(dim=1)], dim=-1)
        predictions = self.head(summary).unsqueeze(-1)
        if self.predict_delta_from_last:
            # Inputs are built as [engineered_features, historical_target], so the last channel
            # at the last timestep is the latest observed target value.
            last_target = inputs[:, -1:, -1:]
            predictions = predictions + last_target
        if return_aux and self.exceed_head is not None:
            exceed_logits = self.exceed_head(summary)
            return predictions, exceed_logits
        return predictions
